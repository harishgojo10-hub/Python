% Prolog Program for NAME and DOB Database

dob(rajesh, date(10,5,2002)).
dob(kumar,  date(22,8,2001)).
dob(priya,  date(15,1,2003)).
dob(anitha, date(30,12,2002)).

% Find DOB:
% ?- dob(priya, D).
% D = date(15,1,2003).

% Find person by DOB:
% ?- dob(Name, date(10,5,2002)).
% Name = rajesh.
