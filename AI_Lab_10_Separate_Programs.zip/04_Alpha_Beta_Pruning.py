# Alpha-Beta Pruning Algorithm

values = [3, 5, 6, 9, 1, 2, 0, -1]

def alpha_beta(depth, node, maximizing, alpha, beta):
    if depth == 3:
        return values[node]

    if maximizing:
        best = -float("inf")

        for child in range(2):
            value = alpha_beta(
                depth + 1,
                node * 2 + child,
                False,
                alpha,
                beta
            )

            best = max(best, value)
            alpha = max(alpha, best)

            if beta <= alpha:
                print("Branch pruned at node:", node)
                break

        return best

    best = float("inf")

    for child in range(2):
        value = alpha_beta(
            depth + 1,
            node * 2 + child,
            True,
            alpha,
            beta
        )

        best = min(best, value)
        beta = min(beta, best)

        if beta <= alpha:
            print("Branch pruned at node:", node)
            break

    return best

result = alpha_beta(0, 0, True, -float("inf"), float("inf"))
print("Optimal value:", result)
