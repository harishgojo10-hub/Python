# Decision Tree using ID3 Algorithm

import math
from collections import Counter

data = [
    ["Sunny","Hot","High","Weak","No"],
    ["Sunny","Hot","High","Strong","No"],
    ["Overcast","Hot","High","Weak","Yes"],
    ["Rain","Mild","High","Weak","Yes"],
    ["Rain","Cool","Normal","Weak","Yes"],
    ["Rain","Cool","Normal","Strong","No"],
    ["Overcast","Cool","Normal","Strong","Yes"],
    ["Sunny","Mild","High","Weak","No"],
    ["Sunny","Cool","Normal","Weak","Yes"],
    ["Rain","Mild","Normal","Weak","Yes"],
    ["Sunny","Mild","Normal","Strong","Yes"],
    ["Overcast","Mild","High","Strong","Yes"],
    ["Overcast","Hot","Normal","Weak","Yes"],
    ["Rain","Mild","High","Strong","No"]
]

features = ["Outlook", "Temperature", "Humidity", "Windy"]

def entropy(rows):
    counts = Counter(row[-1] for row in rows)
    total = len(rows)

    return -sum(
        (n / total) * math.log2(n / total)
        for n in counts.values()
    )

def information_gain(rows, index):
    total_entropy = entropy(rows)
    weighted = 0

    for value in set(row[index] for row in rows):
        subset = [r for r in rows if r[index] == value]

        weighted += (
            len(subset) / len(rows)
        ) * entropy(subset)

    return total_entropy - weighted

def build_tree(rows, available):
    labels = [row[-1] for row in rows]

    if len(set(labels)) == 1:
        return labels[0]

    if not available:
        return Counter(labels).most_common(1)[0][0]

    best = max(
        available,
        key=lambda i: information_gain(rows, i)
    )

    tree = {features[best]: {}}

    for value in set(row[best] for row in rows):
        subset = [row for row in rows if row[best] == value]
        remaining = [i for i in available if i != best]

        tree[features[best]][value] = build_tree(
            subset,
            remaining
        )

    return tree

tree = build_tree(data, list(range(len(features))))

print("Decision Tree:")
print(tree)
