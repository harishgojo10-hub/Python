# Minimax Algorithm for Tic Tac Toe

def check_winner(board):
    lines = [
        (0,1,2), (3,4,5), (6,7,8),
        (0,3,6), (1,4,7), (2,5,8),
        (0,4,8), (2,4,6)
    ]

    for a, b, c in lines:
        if board[a] != " " and board[a] == board[b] == board[c]:
            return board[a]

    return None

def minimax(board, depth, maximizing):
    result = check_winner(board)

    if result == "X":
        return 10 - depth
    if result == "O":
        return depth - 10
    if " " not in board:
        return 0

    if maximizing:
        best = -float("inf")

        for i in range(9):
            if board[i] == " ":
                board[i] = "X"
                best = max(best, minimax(board, depth + 1, False))
                board[i] = " "

        return best

    best = float("inf")

    for i in range(9):
        if board[i] == " ":
            board[i] = "O"
            best = min(best, minimax(board, depth + 1, True))
            board[i] = " "

    return best

def best_move(board):
    best_value = -float("inf")
    move = -1

    for i in range(9):
        if board[i] == " ":
            board[i] = "X"
            value = minimax(board, 0, False)
            board[i] = " "

            if value > best_value:
                best_value = value
                move = i

    return move

board = [" "] * 9
print("Best move for X:", best_move(board) + 1)
