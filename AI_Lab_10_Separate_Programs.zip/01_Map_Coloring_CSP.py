# Map Coloring using Constraint Satisfaction Problem (CSP)

colors = ["Red", "Green", "Blue"]

neighbors = {
    "A": ["B", "C"],
    "B": ["A", "C", "D"],
    "C": ["A", "B", "D"],
    "D": ["B", "C"]
}

def is_safe(region, color, assignment):
    return all(assignment.get(n) != color for n in neighbors[region])

def solve(assignment):
    if len(assignment) == len(neighbors):
        return assignment.copy()

    region = next(r for r in neighbors if r not in assignment)

    for color in colors:
        if is_safe(region, color, assignment):
            assignment[region] = color
            result = solve(assignment)
            if result:
                return result
            del assignment[region]

    return None

solution = solve({})

print("Map Coloring Solution:")
for region, color in solution.items():
    print(region, "->", color)
