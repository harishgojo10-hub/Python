% Prolog Program for PLANETS Database

planet(mercury, 4879, terrestrial).
planet(venus, 12104, terrestrial).
planet(earth, 12742, terrestrial).
planet(mars, 6779, terrestrial).
planet(jupiter, 139820, gas_giant).
planet(saturn, 116460, gas_giant).
planet(uranus, 50724, ice_giant).
planet(neptune, 49244, ice_giant).

% Find planet information:
% ?- planet(earth, Diameter, Type).
% Diameter = 12742,
% Type = terrestrial.

% Find all terrestrial planets:
% ?- planet(Name, _, terrestrial).
