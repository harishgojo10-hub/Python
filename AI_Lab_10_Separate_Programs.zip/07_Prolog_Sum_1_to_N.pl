% Prolog Program to Sum Integers from 1 to N

sum_to_n(0, 0).

sum_to_n(N, Sum) :-
    N > 0,
    N1 is N - 1,
    sum_to_n(N1, S1),
    Sum is N + S1.

% Example Query:
% ?- sum_to_n(5, S).
% S = 15.
