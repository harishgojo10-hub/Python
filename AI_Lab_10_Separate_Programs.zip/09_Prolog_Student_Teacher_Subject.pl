% Prolog Program for STUDENT-TEACHER-SUB-CODE

student(arun, s101).
student(bala, s102).
student(divya, s103).

teacher(kumar, t101).
teacher(priya, t102).

subject(ai, sub101).
subject(dbms, sub102).
subject(prolog, sub103).

teaches(kumar, ai).
teaches(priya, dbms).
teaches(kumar, prolog).

enrolled(arun, ai).
enrolled(bala, dbms).
enrolled(divya, prolog).

teacher_of(Teacher, Subject) :-
    teaches(Teacher, Subject).

student_subject(Student, Subject) :-
    enrolled(Student, Subject).

student_teacher(Student, Teacher, Subject) :-
    enrolled(Student, Subject),
    teaches(Teacher, Subject).

% Example Query:
% ?- student_teacher(arun, T, S).
% T = kumar,
% S = ai.
