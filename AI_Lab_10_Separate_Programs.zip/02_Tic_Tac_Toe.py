# Tic Tac Toe Game

board = [" "] * 9

def display():
    print("\n", board[0], "|", board[1], "|", board[2])
    print("---+---+---")
    print(board[3], "|", board[4], "|", board[5])
    print("---+---+---")
    print(board[6], "|", board[7], "|", board[8])

def winner(player):
    lines = [
        (0,1,2), (3,4,5), (6,7,8),
        (0,3,6), (1,4,7), (2,5,8),
        (0,4,8), (2,4,6)
    ]
    return any(all(board[i] == player for i in line) for line in lines)

player = "X"

for _ in range(9):
    display()

    try:
        position = int(input(f"Player {player}, enter position (1-9): ")) - 1
    except ValueError:
        print("Enter a number.")
        continue

    if position < 0 or position > 8 or board[position] != " ":
        print("Invalid move.")
        continue

    board[position] = player

    if winner(player):
        display()
        print("Player", player, "wins!")
        break

    player = "O" if player == "X" else "X"
else:
    display()
    print("Game Draw!")
