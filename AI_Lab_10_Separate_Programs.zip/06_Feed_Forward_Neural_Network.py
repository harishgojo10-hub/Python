# Feed Forward Neural Network
# XOR problem using NumPy

import numpy as np

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

X = np.array([
    [0,0],
    [0,1],
    [1,0],
    [1,1]
], dtype=float)

y = np.array([
    [0],
    [1],
    [1],
    [0]
], dtype=float)

np.random.seed(1)

# 2 input neurons -> 4 hidden neurons -> 1 output neuron
W1 = np.random.uniform(-1, 1, (2, 4))
W2 = np.random.uniform(-1, 1, (4, 1))

b1 = np.zeros((1, 4))
b2 = np.zeros((1, 1))

learning_rate = 0.5

for epoch in range(10000):

    # Forward propagation
    hidden = sigmoid(np.dot(X, W1) + b1)
    output = sigmoid(np.dot(hidden, W2) + b2)

    # Backpropagation
    error = y - output

    d_output = error * sigmoid_derivative(output)

    hidden_error = d_output.dot(W2.T)
    d_hidden = hidden_error * sigmoid_derivative(hidden)

    W2 += hidden.T.dot(d_output) * learning_rate
    b2 += np.sum(d_output, axis=0, keepdims=True) * learning_rate

    W1 += X.T.dot(d_hidden) * learning_rate
    b1 += np.sum(d_hidden, axis=0, keepdims=True) * learning_rate

print("Predicted Output:")
print(np.round(output, 3))
