# 2. K-Means Clustering

from sklearn.cluster import KMeans
import numpy as np

X = np.array([
    [1, 2], [1, 3], [2, 2],
    [8, 8], [9, 8], [8, 9],
    [4, 5], [5, 5], [5, 6]
])

model = KMeans(n_clusters=3, random_state=42, n_init=10)
model.fit(X)

print("Cluster labels:", model.labels_)
print("Cluster centers:")
print(model.cluster_centers_)

sample = np.array([[2, 3]])
print("Cluster for [2, 3]:", model.predict(sample)[0])
