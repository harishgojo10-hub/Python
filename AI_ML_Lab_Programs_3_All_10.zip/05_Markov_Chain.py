# 5. Basic Markov Chain for Predicting Sequences

import random

transitions = {
    "Sunny": {"Sunny": 0.7, "Rainy": 0.3},
    "Rainy": {"Sunny": 0.4, "Rainy": 0.6}
}

def next_state(current):
    states = list(transitions[current].keys())
    probabilities = list(transitions[current].values())
    return random.choices(states, weights=probabilities)[0]

current = "Sunny"
sequence = [current]

for _ in range(10):
    current = next_state(current)
    sequence.append(current)

print("Predicted sequence:")
print(" -> ".join(sequence))
