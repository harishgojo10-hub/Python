# 3. Reinforcement Learning using Q-Learning
# Simple 1D environment: the agent moves from state 0 to goal state 5.

import random
import numpy as np

states = 6
actions = [-1, 1]       # left, right
goal = 5

Q = np.zeros((states, len(actions)))

alpha = 0.8
gamma = 0.9
epsilon = 0.2
episodes = 500

for _ in range(episodes):
    state = 0

    for _ in range(20):
        if random.random() < epsilon:
            action_index = random.randrange(len(actions))
        else:
            action_index = np.argmax(Q[state])

        next_state = max(0, min(goal, state + actions[action_index]))

        reward = 10 if next_state == goal else -1

        Q[state, action_index] += alpha * (
            reward + gamma * np.max(Q[next_state]) - Q[state, action_index]
        )

        state = next_state

        if state == goal:
            break

print("Learned Q-table:")
print(Q)

state = 0
path = [state]

for _ in range(10):
    action_index = np.argmax(Q[state])
    state = max(0, min(goal, state + actions[action_index]))
    path.append(state)
    if state == goal:
        break

print("Learned path:", path)
