# 6. Object Detection using a Pre-trained YOLO model
# Requires: pip install ultralytics
# Put an image named input.jpg in the same folder.

from ultralytics import YOLO

model = YOLO("yolo11n.pt")
results = model("input.jpg")

for result in results:
    result.save(filename="object_detection_result.jpg")

    print("Detected objects:")
    for box in result.boxes:
        class_id = int(box.cls[0])
        confidence = float(box.conf[0])
        print(
            result.names[class_id],
            "Confidence:",
            round(confidence, 2)
        )

print("Result saved as object_detection_result.jpg")
