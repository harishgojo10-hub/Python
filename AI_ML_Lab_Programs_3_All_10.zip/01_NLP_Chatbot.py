# 1. Simple Chatbot using NLP techniques
import re

responses = {
    "hello": "Hello! How can I help you?",
    "hi": "Hi! Nice to meet you.",
    "name": "I am a simple NLP chatbot.",
    "how are you": "I am fine. Thank you!",
    "bye": "Goodbye!"
}

def chatbot(user_input):
    text = user_input.lower().strip()
    for key, response in responses.items():
        if re.search(r"\b" + re.escape(key) + r"\b", text):
            return response
    return "Sorry, I do not understand that."

print("Chatbot: Type 'bye' to exit.")
while True:
    user = input("You: ")
    reply = chatbot(user)
    print("Chatbot:", reply)
    if user.lower().strip() == "bye":
        break
