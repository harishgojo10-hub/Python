# 4. Image Segmentation using Computer Vision
# Simple color-based segmentation with OpenCV.

import cv2
import numpy as np

image = cv2.imread("input.jpg")

if image is None:
    print("Error: input.jpg not found.")
    print("Place an image named input.jpg in the same folder.")
    raise SystemExit

hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# Detect a green region.
lower_green = np.array([35, 40, 40])
upper_green = np.array([85, 255, 255])

mask = cv2.inRange(hsv, lower_green, upper_green)

segmented = cv2.bitwise_and(image, image, mask=mask)

cv2.imwrite("segmentation_mask.jpg", mask)
cv2.imwrite("segmented_output.jpg", segmented)

print("Segmentation completed.")
print("Saved: segmentation_mask.jpg")
print("Saved: segmented_output.jpg")
