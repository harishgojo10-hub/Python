# 9. Face Recognition using a pre-trained face recognition model
# Requires:
# pip install face_recognition
#
# Put a known face image as "known.jpg" and a test image as "test.jpg".

import face_recognition

known_image = face_recognition.load_image_file("known.jpg")
test_image = face_recognition.load_image_file("test.jpg")

known_encodings = face_recognition.face_encodings(known_image)
test_encodings = face_recognition.face_encodings(test_image)

if not known_encodings:
    print("No face found in known.jpg")
    raise SystemExit

if not test_encodings:
    print("No face found in test.jpg")
    raise SystemExit

known_encoding = known_encodings[0]
test_encoding = test_encodings[0]

match = face_recognition.compare_faces(
    [known_encoding],
    test_encoding,
    tolerance=0.6
)

if match[0]:
    print("Face recognized: Match found.")
else:
    print("Face not recognized: No match.")
