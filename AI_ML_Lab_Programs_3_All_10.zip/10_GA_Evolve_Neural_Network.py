# 10. Genetic Algorithm to evolve a neural network
# The GA evolves a small neural network's weights to learn XOR.

import random
import numpy as np

X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
], dtype=float)

y = np.array([0, 1, 1, 0], dtype=float)

# Network: 2 inputs -> 2 hidden neurons -> 1 output
GENOME_SIZE = 2 * 2 + 2 + 2 + 1
POPULATION_SIZE = 40
GENERATIONS = 100
MUTATION_RATE = 0.1

def sigmoid(x):
    return 1 / (1 + np.exp(-np.clip(x, -50, 50)))

def predict(genome):
    i = 0
    w1 = genome[i:i+4].reshape(2, 2); i += 4
    b1 = genome[i:i+2]; i += 2
    w2 = genome[i:i+2].reshape(2, 1); i += 2
    b2 = genome[i]

    hidden = sigmoid(X @ w1 + b1)
    output = sigmoid(hidden @ w2 + b2)
    return output.ravel()

def fitness(genome):
    predictions = predict(genome)
    error = np.mean((predictions - y) ** 2)
    return 1 / (1 + error)

def crossover(parent1, parent2):
    point = random.randint(1, GENOME_SIZE - 1)
    return (
        np.concatenate([parent1[:point], parent2[point:]]),
        np.concatenate([parent2[:point], parent1[point:]])
    )

def mutate(genome):
    child = genome.copy()
    for i in range(GENOME_SIZE):
        if random.random() < MUTATION_RATE:
            child[i] += random.gauss(0, 0.5)
    return child

population = [
    np.random.uniform(-2, 2, GENOME_SIZE)
    for _ in range(POPULATION_SIZE)
]

for generation in range(GENERATIONS):
    population.sort(key=fitness, reverse=True)
    survivors = population[:10]

    new_population = survivors.copy()

    while len(new_population) < POPULATION_SIZE:
        p1, p2 = random.sample(survivors, 2)
        c1, c2 = crossover(p1, p2)
        new_population.append(mutate(c1))
        if len(new_population) < POPULATION_SIZE:
            new_population.append(mutate(c2))

    population = new_population

best = max(population, key=fitness)

print("Best fitness:", fitness(best))
print("Predicted XOR values:")
print(np.round(predict(best), 3))
print("Expected values:")
print(y)
