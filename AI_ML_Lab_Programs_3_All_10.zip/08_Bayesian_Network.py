# 8. Bayesian Network
# Demonstrates probabilistic relationships:
# Rain -> Wet Grass
# Sprinkler -> Wet Grass
#
# Requires: pip install pgmpy

from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

model = DiscreteBayesianNetwork([
    ("Rain", "WetGrass"),
    ("Sprinkler", "WetGrass")
])

cpd_rain = TabularCPD(
    variable="Rain",
    variable_card=2,
    values=[[0.7], [0.3]]
)

cpd_sprinkler = TabularCPD(
    variable="Sprinkler",
    variable_card=2,
    values=[[0.6], [0.4]]
)

cpd_wet_grass = TabularCPD(
    variable="WetGrass",
    variable_card=2,
    values=[
        [1.0, 0.1, 0.2, 0.01],
        [0.0, 0.9, 0.8, 0.99]
    ],
    evidence=["Rain", "Sprinkler"],
    evidence_card=[2, 2]
)

model.add_cpds(cpd_rain, cpd_sprinkler, cpd_wet_grass)

print("Model valid:", model.check_model())

inference = VariableElimination(model)

result = inference.query(
    variables=["WetGrass"],
    evidence={"Rain": 1}
)

print(result)
