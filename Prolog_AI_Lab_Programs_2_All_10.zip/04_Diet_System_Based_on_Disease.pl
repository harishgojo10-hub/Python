% 4. Prolog Program for Diet Suggestion based on Disease - CO3
% Educational example only; not medical advice.

disease(diabetes).
disease(hypertension).
disease(anemia).
disease(obesity).
disease(fever).

diet(diabetes, [
    "whole grains",
    "leafy vegetables",
    "beans",
    "low sugar fruits"
]).

diet(hypertension, [
    "fresh vegetables",
    "fruits",
    "whole grains",
    "low sodium foods"
]).

diet(anemia, [
    "spinach",
    "lentils",
    "beans",
    "iron rich foods"
]).

diet(obesity, [
    "vegetables",
    "whole grains",
    "lean protein",
    "low calorie foods"
]).

diet(fever, [
    "water",
    "soups",
    "fruits",
    "light meals"
]).

suggest_diet(Disease, Diet) :-
    disease(Disease),
    diet(Disease, Diet).

% Queries:
% ?- suggest_diet(diabetes, Diet).
% ?- suggest_diet(anemia, Diet).
% ?- suggest_diet(obesity, Diet).
