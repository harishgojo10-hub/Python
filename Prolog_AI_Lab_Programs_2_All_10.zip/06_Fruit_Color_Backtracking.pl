% 6. Prolog Program for Fruit and its Color using Backtracking - CO4

fruit_color(apple, red).
fruit_color(banana, yellow).
fruit_color(orange, orange).
fruit_color(grape, purple).
fruit_color(mango, yellow).
fruit_color(guava, green).

% Query all fruit-color combinations using backtracking:
% ?- fruit_color(Fruit, Color).
%
% Press ; after each answer to get the next solution.

% Query a particular fruit:
% ?- fruit_color(mango, Color).
% Color = yellow.

% Query all fruits of a particular color:
% ?- fruit_color(Fruit, yellow).
% Fruit = banana ;
% Fruit = mango.
