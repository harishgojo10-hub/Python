% 9. Prolog Program for Forward Chaining - CO5

% Facts
fact(bird(tweety)).
fact(bird(woody)).
fact(has_feathers(tweety)).
fact(has_feathers(woody)).

% Rules
rule(can_fly(X), [bird(X), has_feathers(X)]).

% Check whether a condition is already known.
known(Fact, Facts) :-
    member(Fact, Facts).

% Apply rules repeatedly to derive new facts.
forward_chain(Facts, Closure) :-
    derive_new_fact(Facts, NewFact),
    !,
    forward_chain([NewFact|Facts], Closure).

forward_chain(Facts, Facts).

derive_new_fact(Facts, Conclusion) :-
    rule(Conclusion, Conditions),
    forall(member(C, Conditions), known(C, Facts)),
    \+ known(Conclusion, Facts).

% Query:
% ?- forward_chain(
%      [bird(tweety), has_feathers(tweety)],
%      Closure).
%
% The closure contains can_fly(tweety).
