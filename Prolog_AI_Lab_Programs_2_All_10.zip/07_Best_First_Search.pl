% 7. Prolog Program to implement Best First Search - CO4

% Directed graph
edge(a, b, 4).
edge(a, c, 2).
edge(b, d, 5).
edge(b, e, 10).
edge(c, f, 3).
edge(f, g, 2).
edge(d, g, 1).
edge(e, g, 3).

% Heuristic values
heuristic(a, 7).
heuristic(b, 5).
heuristic(c, 4).
heuristic(d, 1).
heuristic(e, 3).
heuristic(f, 2).
heuristic(g, 0).

best_first(Start, Goal, Path) :-
    best_first_search([[Start]], Goal, RevPath),
    reverse(RevPath, Path).

best_first_search([[Goal|Rest]|_], Goal, [Goal|Rest]).

best_first_search(Paths, Goal, Solution) :-
    choose_best(Paths, BestPath, Remaining),
    BestPath = [Current|_],
    findall(
        [Next|BestPath],
        (edge(Current, Next, _), \+ member(Next, BestPath)),
        NewPaths
    ),
    append(Remaining, NewPaths, Updated),
    best_first_search(Updated, Goal, Solution).

choose_best([Path|Paths], Best, Remaining) :-
    best_path(Paths, Path, Best, Remaining).

best_path([], Best, Best, []).

best_path([Path|Paths], CurrentBest, Best, Remaining) :-
    Path = [Node|_],
    CurrentBest = [BestNode|_],
    heuristic(Node, H1),
    heuristic(BestNode, H2),
    ( H1 < H2 ->
        NewBest = Path,
        Rest = [CurrentBest|Paths]
    ;
        NewBest = CurrentBest,
        Rest = [Path|Paths]
    ),
    best_path(Rest, NewBest, Best, Remaining).

% Query:
% ?- best_first(a, g, Path).
