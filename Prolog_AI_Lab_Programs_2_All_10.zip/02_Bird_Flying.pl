% 2. Prolog Program to check whether a particular bird can fly - CO3

bird(sparrow).
bird(pigeon).
bird(eagle).
bird(crow).
bird(parrot).
bird(ostrich).
bird(penguin).

can_fly(sparrow).
can_fly(pigeon).
can_fly(eagle).
can_fly(crow).
can_fly(parrot).

cannot_fly(ostrich).
cannot_fly(penguin).

flies(Bird) :-
    can_fly(Bird).

flies(Bird) :-
    bird(Bird),
    cannot_fly(Bird),
    fail.

% Queries:
% ?- can_fly(eagle).
% true.
%
% ?- can_fly(penguin).
% false.
%
% ?- flies(sparrow).
% true.
