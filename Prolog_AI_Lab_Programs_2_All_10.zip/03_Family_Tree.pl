% 3. Prolog Program to implement Family Tree - CO3

male(john).
male(peter).
male(alex).
male(david).
male(robert).

female(mary).
female(susan).
female(lisa).
female(emma).

parent(john, peter).
parent(mary, peter).
parent(john, lisa).
parent(mary, lisa).

parent(peter, alex).
parent(susan, alex).

parent(peter, emma).
parent(susan, emma).

father(Father, Child) :-
    male(Father),
    parent(Father, Child).

mother(Mother, Child) :-
    female(Mother),
    parent(Mother, Child).

grandparent(GP, Child) :-
    parent(GP, Parent),
    parent(Parent, Child).

sibling(X, Y) :-
    parent(P, X),
    parent(P, Y),
    X \= Y.

% Queries:
% ?- father(john, peter).
% true.
%
% ?- mother(mary, lisa).
% true.
%
% ?- grandparent(john, alex).
% true.
%
% ?- sibling(peter, lisa).
% true.
