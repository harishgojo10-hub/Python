% 10. Prolog Program for Backward Chaining - CO5

% Facts
bird(tweety).
has_feathers(tweety).
bird(woody).
has_feathers(woody).

% Rules
can_fly(X) :-
    bird(X),
    has_feathers(X).

% Additional rule
can_breathe(X) :-
    bird(X).

% Prolog naturally uses backward chaining:
% To prove can_fly(tweety), it tries to prove:
% bird(tweety) and has_feathers(tweety).

% Queries:
% ?- can_fly(tweety).
% true.
%
% ?- can_fly(woody).
% true.
%
% ?- can_fly(X).
% X = tweety ;
% X = woody.
%
% ?- can_breathe(tweety).
% true.
