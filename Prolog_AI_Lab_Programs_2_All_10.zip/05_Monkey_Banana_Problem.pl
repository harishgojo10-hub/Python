% 5. Prolog Program to implement Monkey Banana Problem - CO4

% State = state(MonkeyPosition, MonkeyHeight, BoxPosition, BananaStatus)
% MonkeyHeight = floor or on_box
% BananaStatus = hanging or has_banana

initial_state(state(door, floor, window, hanging)).

% Monkey can walk from one position to another.
move(state(P1, floor, Box, Banana), walk(P1, P2),
     state(P2, floor, Box, Banana)) :-
    P1 \= P2.

% Monkey can push the box while standing on the floor.
move(state(P, floor, P, Banana), push(P, P2),
     state(P2, floor, P2, Banana)).

% Monkey climbs onto the box.
move(state(P, floor, P, Banana), climb,
     state(P, on_box, P, Banana)).

% Monkey takes the banana when under it and on the box.
move(state(P, on_box, P, hanging), take_banana,
     state(P, on_box, P, has_banana)).

solve_monkey(State, []) :-
    State = state(_, _, _, has_banana).

solve_monkey(State, [Action|Actions]) :-
    move(State, Action, NextState),
    solve_monkey(NextState, Actions).

% Query:
% ?- initial_state(S), solve_monkey(S, Actions).
% The query searches for a sequence of actions that gets the banana.
