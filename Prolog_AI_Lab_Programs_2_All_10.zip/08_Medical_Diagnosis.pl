% 8. Prolog Program for Medical Diagnosis - CO4
% Educational demonstration only; not a medical diagnosis tool.

symptom(fever).
symptom(cough).
symptom(headache).
symptom(body_pain).
symptom(sneezing).
symptom(sore_throat).

has_symptoms(flu) :-
    symptom(fever),
    symptom(cough),
    symptom(body_pain).

has_symptoms(common_cold) :-
    symptom(sneezing),
    symptom(sore_throat),
    symptom(cough).

has_symptoms(migraine) :-
    symptom(headache).

diagnose(Disease) :-
    has_symptoms(Disease).

% Queries:
% ?- diagnose(flu).
% ?- diagnose(common_cold).
% ?- diagnose(Disease).
%
% In a real system, symptoms should be collected from a qualified
% healthcare professional; this is only a Prolog logic example.
