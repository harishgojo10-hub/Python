# 2. Basic Linear Regression
# Predict a continuous variable using scikit-learn.

import numpy as np
from sklearn.linear_model import LinearRegression

X = np.array([[1], [2], [3], [4], [5]])
y = np.array([2, 4, 5, 8, 10])

model = LinearRegression()
model.fit(X, y)

x_test = np.array([[6]])
prediction = model.predict(x_test)

print("Slope:", model.coef_[0])
print("Intercept:", model.intercept_)
print("Predicted value for x=6:", prediction[0])
