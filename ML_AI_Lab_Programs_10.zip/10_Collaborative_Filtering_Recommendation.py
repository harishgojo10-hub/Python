# 10. Basic Recommendation System using Collaborative Filtering
# User-based collaborative filtering with cosine similarity.

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

users = ["Alice", "Bob", "Charlie", "David"]

# 0 means not rated.
ratings = np.array([
    [5, 4, 0, 0, 3],
    [4, 5, 0, 2, 3],
    [0, 1, 5, 4, 0],
    [0, 2, 4, 5, 0]
], dtype=float)

similarity = cosine_similarity(ratings)

target_user = 0
weighted_scores = similarity[target_user] @ ratings
similarity_sum = similarity[target_user] @ (ratings > 0)

predicted = weighted_scores / np.maximum(similarity_sum, 1e-9)

unrated_items = np.where(ratings[target_user] == 0)[0]
recommendations = sorted(
    [(item, predicted[item]) for item in unrated_items],
    key=lambda x: x[1],
    reverse=True
)

print("Recommendations for", users[target_user])
for item, score in recommendations:
    print(f"Item {item + 1}: predicted rating = {score:.2f}")
