# 5. Decision Tree Classification

from sklearn.tree import DecisionTreeClassifier, export_text

X = [
    [1, 20], [2, 21], [3, 22],
    [8, 30], [9, 31], [10, 32]
]
y = ["No", "No", "No", "Yes", "Yes", "Yes"]

model = DecisionTreeClassifier(random_state=42)
model.fit(X, y)

sample = [[7, 29]]
print("Predicted class:", model.predict(sample)[0])
print("\nDecision Tree Rules:")
print(export_text(model, feature_names=["Experience", "Age"]))
