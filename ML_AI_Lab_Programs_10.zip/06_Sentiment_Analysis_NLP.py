# 6. Sentiment Analysis using NLP
# Simple rule-based sentiment analysis using word lists.

positive_words = {
    "good", "great", "excellent", "amazing", "happy",
    "love", "wonderful", "best", "nice"
}

negative_words = {
    "bad", "poor", "terrible", "awful", "sad",
    "hate", "worst", "boring"
}

def sentiment_analysis(text):
    words = text.lower().split()
    positive = sum(word.strip(".,!?") in positive_words for word in words)
    negative = sum(word.strip(".,!?") in negative_words for word in words)

    if positive > negative:
        return "Positive"
    if negative > positive:
        return "Negative"
    return "Neutral"

text = input("Enter a sentence: ")
print("Sentiment:", sentiment_analysis(text))
