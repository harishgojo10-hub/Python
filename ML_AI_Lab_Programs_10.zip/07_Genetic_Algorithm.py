# 7. Genetic Algorithm
# Maximize f(x) = x^2 for integer x in [0, 31].

import random

POPULATION_SIZE = 10
GENERATIONS = 20
MUTATION_RATE = 0.1

def fitness(x):
    return x * x

def random_individual():
    return random.randint(0, 31)

def crossover(a, b):
    point = random.randint(1, 4)
    mask = (1 << point) - 1
    child1 = (a & mask) | (b & ~mask)
    child2 = (b & mask) | (a & ~mask)
    return child1 & 31, child2 & 31

def mutate(x):
    for bit in range(5):
        if random.random() < MUTATION_RATE:
            x ^= (1 << bit)
    return x

population = [random_individual() for _ in range(POPULATION_SIZE)]

for generation in range(GENERATIONS):
    population.sort(key=fitness, reverse=True)
    survivors = population[:4]

    new_population = survivors[:]
    while len(new_population) < POPULATION_SIZE:
        p1, p2 = random.sample(survivors, 2)
        c1, c2 = crossover(p1, p2)
        new_population.extend([mutate(c1), mutate(c2)])

    population = new_population[:POPULATION_SIZE]

best = max(population, key=fitness)
print("Best solution:", best)
print("Maximum fitness:", fitness(best))
