# 8. Support Vector Machine for Binary Classification

from sklearn import svm

X = [
    [1, 2], [2, 3], [2, 1],
    [8, 8], [9, 8], [8, 9]
]
y = [0, 0, 0, 1, 1, 1]

model = svm.SVC(kernel="linear")
model.fit(X, y)

samples = [[3, 2], [7, 8]]
print("Predictions:", model.predict(samples))
