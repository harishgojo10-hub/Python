# 3. K-Nearest Neighbors Classification

from sklearn.neighbors import KNeighborsClassifier

X = [
    [1, 1], [1, 2], [2, 1],
    [8, 8], [9, 8], [8, 9]
]
y = ["A", "A", "A", "B", "B", "B"]

model = KNeighborsClassifier(n_neighbors=3)
model.fit(X, y)

sample = [[7, 7]]
print("Predicted class:", model.predict(sample)[0])
